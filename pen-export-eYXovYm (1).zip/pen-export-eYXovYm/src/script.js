// JavaScript pour le formulaire de contact
document.getElementById("contactForm").addEventListener("submit", function(event){
    event.preventDefault(); // Empêcher l'envoi du formulaire par défaut
    
    // Récupérer les valeurs des champs
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;
    
    // Ici vous pouvez ajouter le code pour traiter le formulaire (envoi par email, stockage en base de données, etc.)
    
    // Réinitialiser le formulaire
    document.getElementById("contactForm").reset();
    alert("Votre message a été envoyé avec succès !");
});
